import NoteItem from "../components/note/NoteItem";
import { PropTypes } from "prop-types";

const ArchivedList = ({ notes, onDelete, onArchive, onRestore }) => {
  return (
    <div className="flex flex-col gap-4">
      <p className="text-center">Archived Notes</p>
      <div className="container mx-auto grid grid-cols-1 gap-4 md:grid-cols-3 lg:grid-cols-4">
        {notes.map((note) => (
          <NoteItem
            key={note.id}
            id={note.id}
            onDelete={onDelete}
            onArchive={onArchive}
            onRestore={onRestore}
            {...note}
          />
        ))}
      </div>
    </div>
  );
};

ArchivedList.propTypes = {
  notes: PropTypes.array,
  onDelete: PropTypes.func,
  onArchive: PropTypes.func,
  onRestore: PropTypes.func,
};

export default ArchivedList;
